# Renee y el Gatito 🐾

Mini juego web (HTML/Canvas): ayuda a Renee a encontrar el gatito en un laberinto.

## Cómo correr local
Abre `index.html` en tu navegador.

## Publicarlo en GitHub Pages
1. Sube estos archivos a un repo (por ejemplo `renee-gatito-maze`)
2. En GitHub: **Settings → Pages**
3. **Build and deployment**: *Deploy from a branch*
4. Branch: `main` / Folder: `/ (root)`
5. Guarda y abre la URL que te da GitHub.

